<?php
/**
 * Created by PhpStorm.
 * User: Ehtesham Mehmood
 * Date: 11/24/2014
 * Time: 11:55 PM
 */
$conn = new mysqli('localhost', 'jamboree_moni', 'AX2IT8lm+!i*', 'jamboree_moni');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$delete_id=$_GET['del'];
$delete_query="delete  from members WHERE memberID='$delete_id'";//delete query
$run=mysqli_query($conn,$delete_query);
if($run)
{
//javascript function to open in the same window
    echo "<script>window.open('view_users.php?deleted=user has been deleted','_self')</script>";
}

?>