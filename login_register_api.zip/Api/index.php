Visit the below endpoints<br/>

Login:<br/>
http://signaltest.us-east-2.elasticbeanstalk.com/Signal/Api/login.php<br/><br/>

/*

Paramenter Needs

Param name : email
param name : password

*/

Registration:<br/>
http://signaltest.us-east-2.elasticbeanstalk.com/Signal/Api/register.php<br/><br/>
/*
param name : username
Param name : email
param name : password


*/
