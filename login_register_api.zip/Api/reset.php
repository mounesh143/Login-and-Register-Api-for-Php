<?php


include('phpmailer/mail.php');

require_once 'include/DB_Functions.php';
$db = new DB_Functions();

// json response array
$response = array("error" => FALSE);

if (isset($_POST['email'])) {

    // receiving the post params
   
    $email = $_POST['email'];
    

    // check if user is already existed with the same email
    if ($db->isUserExisted($email)) {
			//send email
			$alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
		$pass = array(); //remember to declare $pass as an array
		$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		for ($i = 0; $i < 8; $i++) {
			$n = rand(0, $alphaLength);
			$pass[] = $alphabet[$n];
		}
		$randomkey = implode($pass);
			
			$to = $email;
			$subject = "Password Reset";
			$body = "<p>Someone requested that the password be reset.</p>
			<p>If this was a mistake, just ignore this email and nothing will happen.</p>
			<p>To reset your password, This is the Random Key  <br/>  $randomkey </p>";

			$mail = new Mail();

            // SMTP configuration
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'angola.bdm@gmail.com';
            $mail->Password = '!%BDM@@_2018ti!';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            
			$mail->setFrom('mounishcs143@gmail.com','AngolaSignals');
			$mail->addAddress($to);
			$mail->subject($subject);
			$mail->body($body);
			$mail->send();
			$response["user_email"] = $email;
			$response["random_key"] = $randomkey;
        echo json_encode($response);
        
    } else {
        // user already existed
        $response["error"] = TRUE;
        $response["error_msg"] = "User email not  exist..!";
        echo json_encode($response);
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (email ) is missing!";
    echo json_encode($response);
}
?>
