<?php




require_once 'include/DB_Functions.php';
$db = new DB_Functions();

// json response array
$response = array("error" => FALSE);

if (isset($_POST['email']) && isset($_POST['password']) ) {

    // receiving the post params
   
    $email = $_POST['email'];
    $password = $_POST['password'];
    

    // check if user is already existed with the same email
    if ($db->isUserExisted($email)) {
        
        $us = $db->updatepassword($email,$password);
			
	    $response["error"] = FALSE;
        $response["success_msg"] = "password has updated..!";
        echo json_encode($response);
        
    } else {
        // user already existed
        $response["error"] = TRUE;
        $response["error_msg"] = "User email is not recognised..!";
        echo json_encode($response);
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (email or password) is missing!";
    echo json_encode($response);
}
?>
