<?php

 header('Access-Control-Allow-Origin: *'); 
 header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
 header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT'); 
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "username");
define("DB_PASSWORD", "");
define("DB_DATABASE", "dbname");
?>
