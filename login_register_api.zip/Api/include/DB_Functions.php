<?php

/**
 * @author Ravi Tamada
 * @link http://www.androidhive.info/2012/01/android-login-and-registration-with-php-mysql-and-sqlite/ Complete tutorial
 */

 require_once("DB_Connect.php");
class DB_Functions {

    public $conn;

    // constructor
    function __construct() {
        //require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    // destructor
    function __destruct() {
        
    }

    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($username, $email, $password) {
        //$memberID = memberID('', true);
        //$hash = $this->hashSSHA($password);
       $hashedpassword = password_hash($password, PASSWORD_BCRYPT);// encrypted password
       //die($hashedpassword);
        $active = 'Yes'; // salt
        //die($active);
        $stmt = $this->conn->prepare("INSERT INTO members (username,password, email, active) VALUES('$username', '$hashedpassword', '$email', '$active')");
       
        //$stmt->bind_param($username, $email, $hashedpassword, $active);

        $result = $stmt->execute();
 
        $stmt->close();
        
        /*
        
        prepare('INSERT INTO members (username,password,email,active) VALUES (:username, :password, :email, :active)');
			$stmt->execute(array(
				':username' => $username,
				':password' => $hashedpassword,
				':email' => $email,
				':active' => $activasion
			));
			$id = $db->lastInsertId('memberID');
        
        */

        // check for successful store
        if ($result) {
            //die('sa');
            $stmt = $this->conn->prepare("SELECT * FROM members WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;
        } else {
            die('as');
            return false;
        }
    }
    
    public function getUserByEmailAndPassword($email, $password) {
       // $hashedpassword= $password,PASSWORD_BCRYPT
       //$hashedpassword = base64_encode($password);
       //die($hashedpassword);

        $stmt = $this->conn->prepare("SELECT * FROM members WHERE email ='$email'");

       // $stmt->bind_param($email);

        if ($stmt->execute()) {
            
            $user = $stmt->get_result()->fetch_assoc();
            
           $pass = $password;
           $hash = $user['password'];
           
           
           //var_dump($hash,$pass);die();
           
           if (password_verify($pass, $hash)) {
               
                   //echo 'Password is valid!';
                   //die('kichha');
                   
                   return $user;
           } 

            
            $stmt->close();
            
            
            
           // die($user);
          // die('sa');
            
         
            // verifying user password
           // $salt = $user['salt'];
           // $encrypted_password = $user['password'];
           // $hash = $this->checkhashSSHA($password);
            // check for password equality
           // if ($encrypted_password == $password) {
                // user authentication details are correct
                //return $user;
            //}
        } else {
            //die('as');
            return NULL;
        }
    }

    /**
     * Check user is existed or not
     */
    public function isUserExisted($email) {
        $stmt = $this->conn->prepare("SELECT email from members WHERE email = ?");

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    /**
     * Encrypting password
     * @param password
     * returns salt and encrypted password
     */
    public function hashSSHA($password) {

        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }

    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
    public function checkhashSSHA($password) {

        $hash = password_hash($password, PASSWORD_BCRYPT);

        return $hash;
    }
    
    public function updatepassword($email,$password){
       
        $hashedpassword = password_hash($password, PASSWORD_BCRYPT);
		 //die($hashedpassword);
		 
			$stmt = $this->conn->prepare("UPDATE members SET password = '$hashedpassword' WHERE email = '$email'");
			$stmt->execute();
			echo "sucess";
			
			$stmt->close();
			
			
			
    }
    

}

