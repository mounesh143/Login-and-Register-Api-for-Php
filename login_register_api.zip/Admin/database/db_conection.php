<?php
/**
 * Created by PhpStorm.
 * User: Ehtesham Mehmood
 * Date: 11/21/2014
 * Time: 1:13 AM
 */

$dbcon=mysqli_connect("localhost","username","pasword");

mysqli_select_db($dbcon,"dbname");

?>
